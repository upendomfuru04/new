PHP SDK Portal API 
------------------

1. Dependencies
	phpseclib - http://phpseclib.sourceforge.net/
	
2. Installation
	
	1. Install phpseclib either using PEAR (http://phpseclib.sourceforge.net/pear.htm) or by downloading and extracting into your include path (echo get_include_path() in php or phpinfo page)
	2. Put API folder into include path (<include path>/PortalSDK/api.php)